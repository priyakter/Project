<?php
session_start();
include('../config/dbconn.php');

if (!isset($_SESSION['id']) || (trim($_SESSION['id']) == '')) {
    header('location:user_login_page.php');
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../assets/img/favicon.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Robo Shop</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!-- Fonts and icons -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
    <!-- CSS Files -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/now-ui-kit.css?v=1.1.0" rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="../assets/css/demo.css" rel="stylesheet" />

    <!-- Inserted -->
    <link rel="stylesheet" href="../plugins/datatables/dataTables.bootstrap.css">

</head>

<body class="index-page sidebar-collapse">
    <div class="wrapper"><br>
        <div class="main">
            <div class="section section-basic">
                <div class="container">
                    <h2>
                        <?php
                        include('../config/dbconn.php');
                        $query = mysqli_query($dbconn, "SELECT * FROM `users` WHERE user_id='" . $_SESSION['id'] . "'");
                        $row = mysqli_fetch_array($query);
                        $cid = $row['user_id'];
                        echo $row['firstname'];
                        ?>'s Shopping Cart
                    </h2>
                    <a class="btn btn-primary btn-round" href="user_index.php"><i class="now-ui-icons shopping_basket"></i> &nbsp Shop more items</a>
                    <hr color="orange">
                    <div class="col-md-12">
                        <br>
                        <div class="panel panel-success panel-size-custom">
                            <div class="panel-body">
                                <?php
                                $user_id = $_SESSION['id'];

                                $query3 = mysqli_query($dbconn, "SELECT * FROM order_details WHERE user_id='$user_id' AND order_id=''") or die(mysql_error());
                                $count2 = mysqli_num_rows($query3);
                                ?>

                                <form method="post" id="payment-form">
                                    <h5>[ <small><?php echo $count2; ?> </small>] types of item.</h5>
                                    <table class="table table-condensed table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Product</th>
                                                <th>Description</th>
                                                <th width="100">Quantity</th>
                                                <th width="100">Price(TK)</th>
                                                <th width="100">Total(TK)</th>
                                                <th width="100">Option</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $query = mysqli_query($dbconn, "SELECT * FROM order_details WHERE user_id='$user_id' and order_id=''") or die(mysqli_error());
                                            while ($row = mysqli_fetch_array($query)) {
                                                $count = mysqli_num_rows($query);
                                                $prod_id = $row['prod_id'];

                                                $query2 = mysqli_query($dbconn, "SELECT * FROM products WHERE prod_id='$prod_id'") or die(mysqli_error());
                                                $row2 = mysqli_fetch_array($query2);
                                            ?>

                                                <tr>
                                                    <td> <img width="150" height="100" src="../uploads/<?php echo $row2['prod_pic1']; ?>" alt="" /></td>
                                                    <td><b><?php echo $row2['prod_name']; ?></b><br><br>
                                                        <?php echo $row2['prod_desc'];
                                                        ?>
                                                    </td>
                                                    <td><br><?php echo $row['prod_qty']; ?></td>
                                                    <td><br><?php echo $row2['prod_price']; ?></td>
                                                    <td><br><?php echo $row['total']; ?></td>
                                                    <td>
                                                        <a href="edit_order_details.php?order_id=<?php echo $row['order_details_id']; ?>"><button class="btn btn-warning btn-round" type="button">update qty</button></a>
                                                        <a href="delete_order_details.php?order_id=<?php echo $row['order_details_id']; ?>"><button class="btn btn-danger btn-round" onclick="return confirm('Are you sure you want to delete?')" type="button">remove</button></a>
                                                    </td>
                                                </tr>

                                            <?php
                                            } ?>
                                        </tbody>
                                    </table>

                                    <?php if ($count2 > 0): ?>
                                        <!-- Checkout Buttons -->
                                        <button type="button" id="cash-on-delivery" class="btn btn-success btn-round pull-left" data-toggle="modal" data-target="#myModal">
                                            <i class="now-ui-icons shopping_bag-16"></i> Cash on Delivery
                                        </button>
                                        <button type="button" id="online-payment" class="btn btn-info btn-round pull-right">
                                            <i class="now-ui-icons credit_card"></i> Online Payment
                                        </button>
                                    <?php endif; ?>

                                    <!-- Modal Core -->
                                    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                                    <h4 class="modal-title" id="myModalLabel">Shipping Address:</h4>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="form-group">
                                                        <input type="text" class="form-control" name="shipaddress" placeholder="Complete Address For Delivery Purpose." required />
                                                        <select class="btn btn-warning btn-round dropdown-toggle" size="1" name="city">
                                                            <option value="Gopalganj Sadar">Gopalganj</option>
                                                            <option value="Pachuria,Gopalganj Sadar">Pachuria</option>
                                                            <!-- Other options here -->
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-primary btn-round" data-dismiss="modal">Cancel</button>
                                                    <button type="submit" name="submit"  class="btn btn-success btn-round"><i class="now-ui-icons shopping_delivery-fast"></i> Confirm</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <br><br><br><br>
        <footer class="footer" data-background-color="black">
            <div class="container">
                <nav>
                    <ul>
                        <li>
                            <a href="" target="_blank">
                                19CSE049
                            </a>
                        </li>
                        <li>
                            Priya Akter
                        </li>
                    </ul>
                </nav>
                <div class="copyright">
                    &copy;
                    <script>
                        document.write(new Date().getFullYear())
                    </script>, Dept. of CSE, BSMRSTU
                </div>
            </div>
        </footer>
    </div>
<!-- Core JS Files -->
<script src="../assets/js/core/jquery.3.2.1.min.js" type="text/javascript"></script>
<script src="../assets/js/core/popper.min.js" type="text/javascript"></script>
<script src="../assets/js/core/bootstrap.min.js" type="text/javascript"></script>
<!-- Control Center for Now Ui Kit: parallax effects, scripts for the example pages etc -->
<script src="../assets/js/now-ui-kit.js?v=1.1.0" type="text/javascript"></script>
<script type="text/javascript">
    $(document).ready(function() {
 	//nowuiKit.initSliders();
         //Handle click events for checkout buttons
       // $("#cash-on-delivery").click(function() {
            // Redirect to address selection modal
          //  $("#myModal").modal("show");
      //  });
	
        // Handle online payment button click
		$("#online-payment").click(function() {
            window.location.href = "payment.php";
			 }); 
		
			 
    }); // <-- Add this closing parenthesis
</script>

<!-- Inserted -->
<script src="../plugins/slimScroll/jquery.slimscroll.min.js"></script>
<script src="../plugins/fastclick/fastclick.min.js"></script>
<script src="../plugins/datatables/jquery.dataTables.min.js"></script>
<script src="../plugins/datatables/dataTables.bootstrap.min.js"></script>
<script>
    $(function() {
        $("#example1").DataTable({});
    });
</script>
<!-- Inserted -->


</body>

</html>

