<!DOCTYPE html>
<?php
session_start();
include('../config/dbconn.php');

if (!isset($_SESSION['id']) || (trim($_SESSION['id']) == '')) {
    header('location:user_login_page.php');
    exit();
}

require_once('vendor/autoload.php');

// Set your Stripe API keys
\Stripe\Stripe::setApiKey('sk_test_51PFDmySJkQYy0HIqpn1Do2ro6HPXxMaBiJmbZyQ5AGEUK4RqEwVYXk7cnr7KjoFS5DWGaX2lC2jSIZteudK1uRsH000G44GGz6');
?>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Form</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- CSS Styles -->
    <style>
        /* Add your custom CSS styles here */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }

        .container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
        }

        label {
            font-weight: bold;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button[type="submit"]:hover {
            background-color: #0056b3;
        }

        #error-message {
            color: red;
            margin-bottom: 20px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Payment Form</h1>

        <form id="payment-form" action="userpayment2.php" method="post">

            <!-- Display error messages -->
            <div id="error-message"></div>

            <!-- Card number -->
            <div>
                <label for="card-number">Card Number</label>
                <input type="text" id="card-number" placeholder="1234 5678 9012 3456">
            </div>

            <!-- Expiry date -->
            <div>
                <label for="card-expiry">Expiration Date</label>
                <input type="text" id="card-expiry" placeholder="MM/YY">
            </div>

            <!-- CVC -->
            <div>
                <label for="card-cvc">CVC</label>
                <input type="text" id="card-cvc" placeholder="123">
            </div>

            <!-- Submit button -->
            <button type="submit">Pay Now</button>
        </form>
    </div>

    <!-- JavaScript code to handle form submission -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script>
        // Function to validate form inputs
        function validateForm() {
            var cardNumber = $('#card-number').val().trim();
            var cardExpiry = $('#card-expiry').val().trim();
            var cardCVC = $('#card-cvc').val().trim();

            if (cardNumber === '' || cardExpiry === '' || cardCVC === '') {
                $('#error-message').text('Please fill in all fields.');
                return false;
            }

            return true;
        }

        // Initialize Stripe.js
        var stripe = Stripe('sk_test_51PFDmySJkQYy0HIqpn1Do2ro6HPXxMaBiJmbZyQ5AGEUK4RqEwVYXk7cnr7KjoFS5DWGaX2lC2jSIZteudK1uRsH000G44GGz6');

        // Create an instance of Elements
        var elements = stripe.elements();

        // Create a card Element and mount it to the card-number element
        var card = elements.create('card');
        card.mount('#card-number');

        // Handle form submission
        var form = document.getElementById('payment-form');
        form.addEventListener('submit', function(event) {
            // Prevent form submission
            event.preventDefault();

            // Validate form inputs
            if (!validateForm()) {
                return;
            }

            // Disable the submit button to prevent multiple submissions
            form.querySelector('button').disabled = true;

            // Create a token with the card information
            stripe.createToken(card).then(function(result) {
                if (result.error) {
                    // Display error message if token creation fails
                    var errorElement = document.getElementById('error-message');
                    errorElement.textContent = result.error.message;
                    // Re-enable the submit button
                    form.querySelector('button').disabled = false;
                } else {
                    // Send the token to your server to process the payment
                    stripeTokenHandler(result.token);
                }
            });
        });

        // Function to handle token submission to server
        function stripeTokenHandler(token) {
            // You can send the token to your server using AJAX or by submitting a form
            // For simplicity, we'll just display the token
            var tokenElement = document.createElement('div');
            tokenElement.textContent = 'Token ID: ' + token.id;
            document.body.appendChild(tokenElement);
        }
    </script>
</body>

</html>
